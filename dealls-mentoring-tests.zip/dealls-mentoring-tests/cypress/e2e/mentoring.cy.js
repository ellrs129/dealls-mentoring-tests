describe('Mentoring Page', () => {
  it('should load mentoring page and search for mentor', () => {
    cy.visit('https://job-portal-user-dev-skx7zw44dq-et.a.run.app/mentoring');
    cy.get('input[placeholder*="Search"]').type('UI/UX');
    cy.get('button').contains('Search').click();
    cy.contains('Mentor').should('be.visible');
  });
});
