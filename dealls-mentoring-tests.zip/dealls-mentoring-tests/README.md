# Dealls Mentoring Feature - Cypress Test

This project contains Cypress test automation for the Dealls mentoring feature.

## How to Run Locally

1. Clone the repository  
2. Run `npm install`  
3. Run `npx cypress open` or `npx cypress run`

## Scenario Covered

- Visit mentoring page
- Search for mentor
